user_pref("network.negotiate-auth.trusted-uris", ".da.se,one.da,da.net,da.org");
user_pref("network.negotiate-auth.delegation-uris", ".da.se,one.da,da.net,da.org");
user_pref("network.automatic-ntlm-auth.trusted-uris", ".da.se,one.da,da.net,da.org");